// main.cpp
// Aswin van Woudenberg

#include "c4bot.h"

int main() {
	C4Bot bot;
	bot.run();
	
	return 0;
}


