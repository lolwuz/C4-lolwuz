# C4Bot
A C++ [connect four](https://playground.riddles.io/competitions/four-in-a-row) starter bot for the [riddles.io](https://www.riddles.io) platform.

