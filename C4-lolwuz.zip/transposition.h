//
// Created by lolwuz on 27-Mar-18.
//

#ifndef C4_LOLWUZ_TRANSPOSITION_H
#define C4_LOLWUZ_TRANSPOSITION_H


class transposition {
private:
    struct Entry{
        int key;
        int val;
    };


};

#endif //C4_LOLWUZ_TRANSPOSITION_H
